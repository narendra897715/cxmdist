window.onscroll = function() {myFunction()};

var header = document.getElementById("cxmheader");
var sticky = header.offsetTop;
if(!window.location.pathname.includes('index.html'))
{
header.classList.add('header-border')
 } else {
  header.classList.remove('header-border')
 }
 var hamburger1 = header.children[1].children[0];
 if(window.location.pathname.includes('index.html')) {
   hamburger1.style.color = 'white';
  } else {
   hamburger1.style.color = 'black';
  }
function myFunction() {
    var childheader = header.children[2].children[0].children;
    var hamburger = header.children[1].children[0];
  if (window.pageYOffset > sticky) {
    //   var chilheader = header.children;
    //   console.log(chilheader[0].children)[0].children;
   
     for(var i=0;i<childheader.length;i++){
        var subchild = childheader[i].children[0];
        if(subchild.tagName === "A") {
            subchild.style.color = 'black';
          }
     }
     if(window.location.pathname.includes('index.html')) {
      hamburger.style.color = 'black';
     } 
     
    header.classList.add("stickyheader");
  } else {
    for(var i=0;i<childheader.length;i++){
        var subchild = childheader[i].children[0];
        if(subchild.tagName === "A") {
            subchild.style.color = 'white';
          }
     }
     if(window.location.pathname.includes('index.html')) {
      hamburger.style.color = 'white';
     } 
    header.classList.remove("stickyheader");
  }
}
function isNumber(evt) {
  evt = (evt) ? evt : window.event;
  var charCode = (evt.which) ? evt.which : evt.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    alert("Please enter only Numbers.");
    return false;
  }

  return true;
}